import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Briefcase, Heart, Calendar, Award, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import StatCard from "@/components/StatCard";
import SectionHeading from "@/components/SectionHeading";
import heroCampus from "@/assets/hero-campus.jpg";

const features = [
  {
    icon: Search,
    title: "Alumni Directory",
    desc: "Find classmates by year, department, industry, or location.",
    link: "/directory",
  },
  {
    icon: Briefcase,
    title: "Job Portal",
    desc: "Explore career opportunities posted by fellow alumni.",
    link: "/jobs",
  },
  {
    icon: Calendar,
    title: "Events & Reunions",
    desc: "Stay updated on reunions, workshops, and networking events.",
    link: "/events",
  },
  {
    icon: Award,
    title: "Success Stories",
    desc: "Celebrate achievements of our distinguished alumni.",
    link: "/stories",
  },
  {
    icon: Heart,
    title: "Donation Portal",
    desc: "Give back and support the next generation of students.",
    link: "/donate",
  },
  {
    icon: Users,
    title: "Networking Hub",
    desc: "Connect with alumni who share your interests and goals.",
    link: "/directory",
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroCampus} alt="Campus" className="w-full h-full object-cover" />
          <div className="absolute inset-0 gradient-hero opacity-80" />
        </div>
        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 rounded-full text-sm font-semibold bg-accent/20 text-accent border border-accent/30 mb-6">
              Est. 1965 — Government Engineering College
            </span>
            <h1 className="font-display text-4xl md:text-6xl lg:text-7xl font-bold text-primary-foreground mb-6 leading-tight">
              Where Graduates{" "}
              <span className="text-accent">Stay Connected</span>
            </h1>
            <p className="text-primary-foreground/80 text-lg md:text-xl max-w-2xl mx-auto mb-10 font-body">
              A thriving community of 50,000+ alumni — networking, mentoring,
              and building the future together.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold text-base shadow-gold"
                asChild
              >
                <Link to="/register">Join the Network</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
                asChild
              >
                <Link to="/directory">Explore Directory</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 -mt-16 relative z-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            <StatCard icon={Users} value="50,000+" label="Alumni Worldwide" delay={0} />
            <StatCard icon={Briefcase} value="1,200+" label="Jobs Posted" delay={0.1} />
            <StatCard icon={Calendar} value="85+" label="Events This Year" delay={0.2} />
            <StatCard icon={Heart} value="₹2.5Cr" label="Donations Raised" delay={0.3} />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <SectionHeading
            title="Everything You Need"
            subtitle="Our platform brings together career services, networking, events, and philanthropy in one place."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  to={f.link}
                  className="block p-8 rounded-2xl bg-card shadow-card hover:shadow-elevated transition-shadow group"
                >
                  <f.icon className="h-10 w-10 text-accent mb-4 group-hover:scale-110 transition-transform" />
                  <h3 className="font-display text-xl font-semibold text-foreground mb-2">
                    {f.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">{f.desc}</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 gradient-hero">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
              Ready to Reconnect?
            </h2>
            <p className="text-primary-foreground/70 max-w-xl mx-auto mb-8">
              Join thousands of alumni who are already part of our vibrant community.
            </p>
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold shadow-gold"
              asChild
            >
              <Link to="/register">Create Your Profile</Link>
            </Button>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
