import { Link } from "react-router-dom";
import { GraduationCap, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => (
  <footer className="gradient-hero text-primary-foreground">
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-7 w-7 text-accent" />
            <span className="font-display text-xl font-bold">AlumniConnect</span>
          </div>
          <p className="text-primary-foreground/70 text-sm leading-relaxed">
            Building lifelong connections between graduates and their alma mater since 1965.
          </p>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            {["Directory", "Jobs", "Events", "Stories", "Donate"].map((l) => (
              <li key={l}>
                <Link to={`/${l.toLowerCase()}`} className="hover:text-accent transition-colors">
                  {l}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Resources</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            {["Mentorship Program", "Career Services", "Annual Report", "Privacy Policy"].map((l) => (
              <li key={l}>
                <span className="hover:text-accent transition-colors cursor-pointer">{l}</span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg font-semibold mb-4">Contact</h4>
          <ul className="space-y-3 text-sm text-primary-foreground/70">
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-accent" />
              alumni@gec.edu
            </li>
            <li className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-accent" />
              +91 98765 43210
            </li>
            <li className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-accent" />
              Government Engineering College
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-primary-foreground/10 mt-12 pt-8 text-center text-sm text-primary-foreground/50">
        © {new Date().getFullYear()} AlumniConnect — Government Engineering College. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
