import { motion } from "framer-motion";
import { MapPin, Briefcase, Clock, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

const jobs = [
  { title: "Senior Software Engineer", company: "Infosys", location: "Bangalore", type: "Full-time", posted: "2 days ago", tags: ["React", "Node.js", "AWS"] },
  { title: "Data Analyst", company: "TCS", location: "Hyderabad", type: "Full-time", posted: "5 days ago", tags: ["Python", "SQL", "Tableau"] },
  { title: "Product Manager", company: "Flipkart", location: "Bangalore", type: "Full-time", posted: "1 week ago", tags: ["Strategy", "Analytics"] },
  { title: "Mechanical Design Engineer", company: "Tata Motors", location: "Pune", type: "Full-time", posted: "3 days ago", tags: ["CAD", "SolidWorks"] },
  { title: "Frontend Developer", company: "Razorpay", location: "Remote", type: "Contract", posted: "1 day ago", tags: ["TypeScript", "React"] },
  { title: "Civil Project Manager", company: "L&T Construction", location: "Mumbai", type: "Full-time", posted: "4 days ago", tags: ["Project Planning", "AutoCAD"] },
];

const Jobs = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4">
        <SectionHeading title="Job Portal" subtitle="Career opportunities shared by alumni for alumni. Find your next role." />

        <div className="max-w-3xl mx-auto space-y-4">
          {jobs.map((job, i) => (
            <motion.div
              key={job.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-2xl p-6 shadow-card hover:shadow-elevated transition-shadow"
            >
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                <div className="space-y-2">
                  <h3 className="font-display text-xl font-semibold text-foreground">{job.title}</h3>
                  <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Briefcase className="h-3.5 w-3.5" /> {job.company}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" /> {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" /> {job.posted}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {job.tags.map((t) => (
                      <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                    ))}
                  </div>
                </div>
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90 shrink-0">
                  <ExternalLink className="h-4 w-4 mr-1" /> Apply
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
    <Footer />
  </div>
);

export default Jobs;
