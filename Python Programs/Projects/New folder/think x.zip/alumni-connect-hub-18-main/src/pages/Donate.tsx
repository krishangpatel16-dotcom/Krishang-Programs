import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, GraduationCap, Building, BookOpen, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";
import { toast } from "sonner";

const causes = [
  { id: "scholarship", label: "Student Scholarships", icon: GraduationCap, desc: "Fund deserving students' education" },
  { id: "infrastructure", label: "Campus Infrastructure", icon: Building, desc: "Modernize labs and facilities" },
  { id: "research", label: "Research Grants", icon: BookOpen, desc: "Support cutting-edge research" },
  { id: "sports", label: "Sports & Athletics", icon: Trophy, desc: "Upgrade sports facilities" },
];

const amounts = ["₹500", "₹1,000", "₹5,000", "₹10,000", "₹25,000"];

const Donate = () => {
  const [selectedCause, setSelectedCause] = useState("scholarship");
  const [selectedAmount, setSelectedAmount] = useState("₹5,000");
  const [customAmount, setCustomAmount] = useState("");

  const handleDonate = () => {
    toast.success("Thank you for your generous contribution! A confirmation email will be sent shortly.");
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <SectionHeading title="Support Your Alma Mater" subtitle="Your contributions shape the future of the next generation of engineers." />

          <div className="max-w-2xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-2xl p-8 shadow-elevated"
            >
              {/* Cause selection */}
              <h3 className="font-display text-xl font-semibold text-foreground mb-4">Choose a Cause</h3>
              <RadioGroup value={selectedCause} onValueChange={setSelectedCause} className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                {causes.map((c) => (
                  <Label
                    key={c.id}
                    htmlFor={c.id}
                    className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                      selectedCause === c.id ? "border-accent bg-accent/5" : "border-border hover:border-accent/50"
                    }`}
                  >
                    <RadioGroupItem value={c.id} id={c.id} className="sr-only" />
                    <c.icon className={`h-6 w-6 shrink-0 ${selectedCause === c.id ? "text-accent" : "text-muted-foreground"}`} />
                    <div>
                      <p className="font-semibold text-sm text-foreground">{c.label}</p>
                      <p className="text-xs text-muted-foreground">{c.desc}</p>
                    </div>
                  </Label>
                ))}
              </RadioGroup>

              {/* Amount */}
              <h3 className="font-display text-xl font-semibold text-foreground mb-4">Select Amount</h3>
              <div className="flex flex-wrap gap-3 mb-4">
                {amounts.map((a) => (
                  <button
                    key={a}
                    onClick={() => { setSelectedAmount(a); setCustomAmount(""); }}
                    className={`px-5 py-2.5 rounded-lg font-semibold text-sm transition-all ${
                      selectedAmount === a
                        ? "bg-accent text-accent-foreground shadow-gold"
                        : "bg-secondary text-secondary-foreground hover:bg-accent/10"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
              <div className="mb-8">
                <Input
                  placeholder="Or enter custom amount (₹)"
                  value={customAmount}
                  onChange={(e) => { setCustomAmount(e.target.value); setSelectedAmount(""); }}
                />
              </div>

              <Button
                size="lg"
                onClick={handleDonate}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90 font-semibold text-base shadow-gold"
              >
                <Heart className="h-5 w-5 mr-2" /> Donate Now
              </Button>

              <p className="text-xs text-muted-foreground text-center mt-4">
                All donations are tax-deductible under Section 80G. Secure payment powered by Razorpay.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Donate;
