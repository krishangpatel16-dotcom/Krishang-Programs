import { motion } from "framer-motion";
import { Calendar, MapPin, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

const events = [
  { title: "Annual Alumni Meet 2026", date: "Mar 15, 2026", time: "10:00 AM", location: "College Campus", type: "Reunion", attendees: 450, desc: "The grand annual reunion bringing together alumni from all batches." },
  { title: "Tech Talks: AI & The Future", date: "Feb 22, 2026", time: "3:00 PM", location: "Virtual", type: "Workshop", attendees: 120, desc: "Distinguished alumni share insights on AI trends and career opportunities." },
  { title: "Startup Networking Mixer", date: "Mar 5, 2026", time: "6:00 PM", location: "Bangalore Hub", type: "Networking", attendees: 85, desc: "Connect with alumni entrepreneurs and investors in the startup ecosystem." },
  { title: "Career Mentorship Program", date: "Ongoing", time: "Flexible", location: "Online", type: "Mentorship", attendees: 200, desc: "One-on-one mentorship pairing senior alumni with recent graduates." },
  { title: "Golden Jubilee Batch 1976", date: "Apr 10, 2026", time: "11:00 AM", location: "College Auditorium", type: "Reunion", attendees: 65, desc: "Celebrating 50 years since the batch of 1976 graduated." },
];

const typeColors: Record<string, string> = {
  Reunion: "bg-accent/10 text-accent",
  Workshop: "bg-primary/10 text-primary",
  Networking: "bg-green-100 text-green-700",
  Mentorship: "bg-purple-100 text-purple-700",
};

const Events = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4">
        <SectionHeading title="Events & Reunions" subtitle="Stay connected through meetups, workshops, and reunions." />

        <div className="max-w-3xl mx-auto space-y-6">
          {events.map((e, i) => (
            <motion.div
              key={e.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-2xl p-6 shadow-card hover:shadow-elevated transition-shadow"
            >
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-shrink-0 w-20 h-20 rounded-xl gradient-hero flex items-center justify-center">
                  <Calendar className="h-8 w-8 text-accent" />
                </div>
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-xl font-semibold text-foreground">{e.title}</h3>
                    <Badge className={typeColors[e.type]}>{e.type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{e.desc}</p>
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />{e.date}</span>
                    <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />{e.time}</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{e.location}</span>
                    <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" />{e.attendees} attending</span>
                  </div>
                </div>
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90 shrink-0 self-start">
                  Register
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
    <Footer />
  </div>
);

export default Events;
