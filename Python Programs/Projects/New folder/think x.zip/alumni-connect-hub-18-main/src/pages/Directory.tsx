import { useState } from "react";
import { motion } from "framer-motion";
import { Search, MapPin, Briefcase, GraduationCap } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

const alumni = [
  { name: "Priya Sharma", year: "2018", dept: "Computer Science", role: "Software Engineer @ Google", location: "Bangalore", initials: "PS" },
  { name: "Rahul Patel", year: "2015", dept: "Mechanical", role: "Product Manager @ Tesla", location: "San Francisco", initials: "RP" },
  { name: "Ananya Gupta", year: "2020", dept: "Electronics", role: "Data Scientist @ Amazon", location: "Hyderabad", initials: "AG" },
  { name: "Vikram Singh", year: "2012", dept: "Civil", role: "Project Director @ L&T", location: "Mumbai", initials: "VS" },
  { name: "Meera Krishnan", year: "2019", dept: "Computer Science", role: "UX Designer @ Microsoft", location: "Pune", initials: "MK" },
  { name: "Arjun Reddy", year: "2016", dept: "Electrical", role: "Founder @ GreenTech", location: "Chennai", initials: "AR" },
  { name: "Sneha Iyer", year: "2021", dept: "Information Tech", role: "ML Engineer @ Meta", location: "Delhi", initials: "SI" },
  { name: "Karthik Nair", year: "2014", dept: "Mechanical", role: "VP Engineering @ Flipkart", location: "Bangalore", initials: "KN" },
];

const departments = ["All Departments", "Computer Science", "Mechanical", "Electronics", "Civil", "Electrical", "Information Tech"];

const Directory = () => {
  const [search, setSearch] = useState("");
  const [dept, setDept] = useState("All Departments");

  const filtered = alumni.filter((a) => {
    const matchSearch = a.name.toLowerCase().includes(search.toLowerCase()) || a.role.toLowerCase().includes(search.toLowerCase());
    const matchDept = dept === "All Departments" || a.dept === dept;
    return matchSearch && matchDept;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <SectionHeading title="Alumni Directory" subtitle="Search and connect with fellow graduates from across the globe." />

          <div className="flex flex-col sm:flex-row gap-4 mb-10 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or role..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={dept} onValueChange={setDept}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {departments.map((d) => (
                  <SelectItem key={d} value={d}>{d}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {filtered.map((a, i) => (
              <motion.div
                key={a.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-card rounded-2xl p-6 shadow-card hover:shadow-elevated transition-shadow text-center"
              >
                <Avatar className="h-16 w-16 mx-auto mb-4 bg-primary text-primary-foreground">
                  <AvatarFallback className="bg-primary text-primary-foreground font-display text-lg">
                    {a.initials}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-display text-lg font-semibold text-foreground">{a.name}</h3>
                <div className="flex items-center justify-center gap-1 text-sm text-muted-foreground mt-1">
                  <GraduationCap className="h-3.5 w-3.5" />
                  {a.dept} • {a.year}
                </div>
                <div className="flex items-center justify-center gap-1 text-sm text-accent font-medium mt-2">
                  <Briefcase className="h-3.5 w-3.5" />
                  {a.role}
                </div>
                <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3" />
                  {a.location}
                </div>
              </motion.div>
            ))}
          </div>

          {filtered.length === 0 && (
            <p className="text-center text-muted-foreground mt-10">No alumni found matching your criteria.</p>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Directory;
