import { motion } from "framer-motion";
import { Award, ExternalLink } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import SectionHeading from "@/components/SectionHeading";

const stories = [
  { name: "Dr. Anil Kumar", batch: "1992", field: "Aerospace", story: "Led the propulsion systems team at ISRO for the Chandrayaan-3 mission, contributing to India's historic moon landing.", initials: "AK" },
  { name: "Neha Saxena", batch: "2010", field: "FinTech", story: "Founded PaySmart, a fintech startup now valued at ₹500 Cr, serving 2M+ users across rural India.", initials: "NS" },
  { name: "Rajesh Menon", batch: "2005", field: "Civil Engineering", story: "Designed the award-winning eco-bridge project connecting remote villages in Kerala, winning the National Engineering Excellence Award.", initials: "RM" },
  { name: "Deepa Verma", batch: "2015", field: "AI Research", story: "Published groundbreaking research at NeurIPS on medical AI diagnostics, now leading AI health initiatives at WHO.", initials: "DV" },
  { name: "Suresh Babu", batch: "1998", field: "Social Impact", story: "Established the Rural Education Foundation, providing free engineering coaching to 10,000+ students from underserved communities.", initials: "SB" },
  { name: "Kavitha Rao", batch: "2008", field: "Entrepreneurship", story: "Co-founded GreenBuild Technologies, pioneering sustainable construction materials now used in 200+ commercial projects.", initials: "KR" },
];

const Stories = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4">
        <SectionHeading title="Success Stories" subtitle="Celebrating the achievements of our remarkable alumni community." />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {stories.map((s, i) => (
            <motion.div
              key={s.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl p-8 shadow-card hover:shadow-elevated transition-shadow flex flex-col"
            >
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-14 w-14 bg-primary text-primary-foreground">
                  <AvatarFallback className="bg-primary text-primary-foreground font-display text-lg">{s.initials}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-display text-lg font-semibold text-foreground">{s.name}</h3>
                  <p className="text-sm text-muted-foreground">Batch of {s.batch} • {s.field}</p>
                </div>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed flex-1">{s.story}</p>
              <div className="mt-4 pt-4 border-t border-border">
                <div className="flex items-center gap-1 text-accent text-sm font-medium cursor-pointer hover:underline">
                  <Award className="h-4 w-4" /> Read Full Story <ExternalLink className="h-3 w-3 ml-1" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
    <Footer />
  </div>
);

export default Stories;
